package helper.recruit.community.exception;

public interface ICustomizeErrorCode {
    String getMessage();
    Integer getCode();
}
