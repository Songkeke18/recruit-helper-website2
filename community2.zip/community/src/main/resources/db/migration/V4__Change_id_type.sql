alter table QUESTION alter column ID BIGINT auto_increment;
alter table `USER` alter column ID BIGINT auto_increment;