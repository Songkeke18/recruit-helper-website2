alter table QUESTION alter column CREATOR  BIGINT auto_increment not null;
alter table COMMENT alter column COMMENTATOR BIGINT auto_increment not null;
